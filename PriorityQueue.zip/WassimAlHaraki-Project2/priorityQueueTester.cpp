/*-- priorityQueueTester.cpp -------------------------------------------------
   This file tests PriorityQueue member functions.
-------------------------------------------------------------------------*/

#include "priorityQueue.h"

#include <string>

using std::cout;
using std::cin;
using std::string;

void displayOptions();

int main() {

    PriorityQueue<string> printerQueue;
    int choice;
    int priority;
    string document;

    cout << "\nWelcome to the printer program!\n"
         << "An empty printer queue of documents has been created for you.\n";
    displayOptions();
    cin >> choice;

    while (choice != 0) {
        switch (choice) {
            case 1:
                cout << "\nEnter a document to add to the printer:\n";
                cin.ignore();
                getline(cin, document);
                printerQueue.enqueue(document);
                cout << "\nDocument was added successfully to the "
                     << "printer\n";
                break;

            case 2:
                cout << "\nEnter the priority of the document "
                     << "(1 to 5, 5 represents the highest priority): ";
                cin >> priority;
                if (priority < 1 || priority > 5) {
                    cout << "\nInvalid priority\n";
                    break;
                }
                cout << "\nEnter a document to add to the printer:\n";
                cin.ignore();
                getline(cin, document);
                printerQueue.enqueue(document, priority);
                cout << "\nDocument was added successfully to the "
                     << "printer\n";
                break;

            case 3:
                if (printerQueue.isEmpty()) {
                    cerr << "\nPrinter is empty\n";
                    break;
                }

                printerQueue.dequeue();
                cout << "\nPrinting";
                //Prints '.' every second for 3 seconds
                for (int i = 0; i < 4; i++) {
                    int currentTime = time(NULL);
                    while (time(NULL) - currentTime < 1);
                    if (i != 3)
                        cout << '.';
                }
                cout << "\n\nDocument has been printed\n";
                break;

            case 4:
                if (printerQueue.isEmpty())
                    cout << "\nPrinter is empty\n";
                else
                    cout << "\nPrinter is not empty\n";
                break;

            case 5:
                if (printerQueue.isEmpty())
                    cerr << "\nPrinter is empty\n";
                else
                    cout << "\nFirst document in printer:\n\n"
                         << printerQueue.front() << "\n";
                break;

            case 6:
                if (printerQueue.isEmpty())
                    cerr << "\nPrinter is empty\n";
                else
                    cout << "\nAll documents in printer:\n"
                         << printerQueue;
                break;

            case 0:
                break;

            default:
                cout << "\nInvalid option\n";
        }

        displayOptions();
        cin >> choice;
    }

    cout << "\nThank you for using the program.\n\n";
    return 0;
}

void displayOptions()
{
    cout << "\nPlease choose one of the following options:\n\n"
         << "1- " << "Add a document\n"
         << "2- " << "Add a document with priority\n"
         << "3- " << "Print a document\n"
         << "4- " << "Check if printer is empty\n"
         << "5- " << "View first document in printer\n"
         << "6- " << "View all documents in printer\n"
         << "0- " << "Exit\n\n";
}