/**
 * @brief This header file defines the data type PriorityQueue for 
 *      processing Queues.
 * 
 * @file priorityQueue.h
 * 
 * @author Wassim Al Haraki
 * 
 * @date 21-11-2022
 */

/*-- priorityQueue.h ----------------------------------------------------
    Basic operations are:
        Constructor
        Copy constructor
        =:                  Assignment operator
        Destructor
        isEmpty:            Check if queue is empty
        enqueue:            Add element to end of queue
        dequeue:            Remove element from front of queue
        front:              Return first element in queue
        display:            Output the queue
        <<:                 Output operator

    Class Invariant:
        1. mySize >= 0
        2. Queue size is not limited
 -------------------------------------------------------------------------*/
#ifndef PRIORITYQUEUE
#define PRIORITYQUEUE

#include <iostream>

using std::cerr;
using std::ostream;

template <typename ElementType> 
class PriorityQueue {

    public:
    /******** Functions Members ********/
        /*----------------------------------------------------------------------
            Constructs a PriorityQueue object.

            Precondition:  None
            Postcondition: An empty PriorityQueue object is constructed;
                myFront = NULL, myBack = NULL, and mySize = 0.
        -----------------------------------------------------------------------*/
        PriorityQueue() {
            mySize = 0;
            myBack = NULL;
            myFront = NULL;
        }

        /*----------------------------------------------------------------------
            Constructs a copy of a PriorityQueue object.

            Precondition:  A copy of orig is needed; orig is a const
                reference parameter. 
            Postcondition: A copy of orig has been constructed.
        -----------------------------------------------------------------------*/
        PriorityQueue(const PriorityQueue& orig) {
            mySize = 0;
            myBack = NULL;
            myFront = NULL;

            // if q is empty return
            if (orig.isEmpty())
                return;

            NodePtr current = orig.myFront;
            
            // insert all elements from orig into this queue
            for (; mySize < orig.mySize; current = current->next)
                enqueue(current->data, current->priority);
        }

        /*----------------------------------------------------------------------
            Assigns a copy of a PriorityQueue object to this object.

            Precondition:  None
            Postcondition: A copy of right has been assigned to this
                object. A const reference to this queue is returned.
        -----------------------------------------------------------------------*/
        const PriorityQueue& operator=(const PriorityQueue& right) {
            // in case of self assignment, return this queue
            if (this == &right)
                return *this;
            // else destroy this queue 
            this->~PriorityQueue();

            mySize = 0;
            myFront = NULL;
            myBack = NULL;
            
            // if right is empty, return
            if (right.isEmpty())
                return *this;

            NodePtr current = right.myFront;

            // insert all elements from right into this queue
            for (; mySize < right.mySize; current = current->next)
                enqueue(current->data, current->priority);

            return *this;
        }

        /*----------------------------------------------------------------------
            Destroys a PriorityQueue object.

            Precondition:  The life of a PriorityQueue object is over.
            Postcondition: The dynamically allocated memory for the Node
                objects in the queue has been returned to the heap.
        -----------------------------------------------------------------------*/
        ~PriorityQueue() {
            if (isEmpty())
                return;

            // current points to myFront
            NodePtr current = myFront;

            // toDelete points to the same node
            NodePtr toDelete = current;

            // current moves, toDelete is deleted
            // then toDelete follows current until all
            // nodes are deleted
            for (int i = 0; i < mySize; i++) {
                current = current->next;
                delete toDelete;
                toDelete = current;
            }
        }

        /*----------------------------------------------------------------------
            Checks if the queue is empty.

            Precondition:  None
            Postcondition: True is returned if the queue is empty, false if not.
        -----------------------------------------------------------------------*/
        inline bool isEmpty() const {
            return mySize == 0;
        }

        /*----------------------------------------------------------------------
            Adds an element into the queue.

            Precondition:  Data is a nonnull variable of type ElementType.
            Postcondition: Element has been inserted into the queue according
                to its priority (provided priority is valid).
        -----------------------------------------------------------------------*/
        bool enqueue(const ElementType& data, int priority = 1) {
            // if priority is invalid, return false
            if (priority < 1 || priority > 5)
                return false;
            
            NodePtr toInsert = new Node(data, priority);

            // inserting into empty queue
            if (isEmpty()) {
                myBack = toInsert;
                myFront = toInsert;
                mySize++;
                return true;
            }

            // if toInsert has the highest priority
            // inserting into front of queue
            if (toInsert->priority > myFront->priority) {
                toInsert->next = myFront;
                myFront = toInsert;
                mySize++;
                return true;
            }

            // if toInsert has the lowest priority
            // inserting into back of queue
            if (toInsert->priority <= myBack->priority) {
                myBack->next = toInsert;
                myBack = toInsert;
                mySize++;
                return true;
            }

            // inserting into middle of queue
            NodePtr pred = myFront;

            // find the node before the node that has a strictly
            // lower priority than toInsert (no need to worry about
            // segmentation faults since the previous if statement
            // takes care of inserting into end of list)
            while (pred->next->priority >= toInsert->priority)
                pred = pred->next;

            toInsert->next = pred->next;
            pred->next = toInsert;
            mySize++;
            return true;
        }

        /*----------------------------------------------------------------------
            Removes the front element from the queue.

            Precondition:  Queue is not empty.
            Postcondition: Element at the front of the queue has been removed
                (provided queue is not empty).
        ----------------------------------------------------------------------*/
        bool dequeue() {
            
            if (isEmpty()) {
                cerr << "Queue is empty\n";
                return false;
            }

            // removing from a queue of 1 element
            if (mySize == 1) {
                delete myFront;
                myFront = NULL;
                myBack = NULL;
                mySize--;
                return true;
            }

            NodePtr toDelete = myFront;
            // myFront points to the next
            myFront = myFront->next;
            // toDelete is deleted
            delete toDelete;
            mySize--;
            return true;
        }

        /*----------------------------------------------------------------------
            Returns data of the front element in the queue.

            Precondition:  Queue is not empty.
            Postcondition: Data of the front element in the queue is returned
                (provided that queue is not empty, else a garbage value
                is returned).
        -----------------------------------------------------------------------*/
        inline ElementType front() const {
            ElementType garbage;
            if (isEmpty())
                return garbage;
            else
                return myFront->data;
        }

        /*----------------------------------------------------------------------
            Displays a queue.

            Precondition:  The ostream out is open. 
            Postcondition: The queue represented by this PriorityQueue object
                has been inserted into out. 
        -----------------------------------------------------------------------*/
        ostream& display(ostream& out) const {
            if (isEmpty()) {
                out << "\nQueue is empty\n\n";
                return out;
            }

            // displays the queue elements numbered
            // starting from 1
            NodePtr current = myFront;
            out << "\n";
            for (int i = 0; i < mySize; i++) {
                out << i + 1 << "- " << current->data << "\n";
                current = current->next;
            }
            out << "\n";
            return out;
        }

    private:

        /**
         * A Node holds data, its priority, and points to the next Node.
         * 
         * All Nodes initially hold what is passed to it as data
         * and priority, and NULL as the pointer pointing to the
         * next Node.
         * 
         * User is free to change data and pointer after initialization
         * BUT NOT the priority after it has been inserted into a queue.
         */
        struct Node {
            
            public:
                /******** Data Members ********/
                ElementType data;   // data of Node
                int priority;       // priority of the data
                Node* next;         // pointer to the next Node

                /*----------------------------------------------------------------------
                    Constructs a Node object

                    Precondition:  value is a nonnull variable of type ElementType.
                    Postcondition: A Node is constructed; data = value,
                        this priority = priority, and next = NULL.
                ----------------------------------------------------------------------*/
                Node(ElementType value, int priority) {
                    data = value;
                    this->priority = priority;
                    next = NULL;
                }
        };//--- end of Node struct

        typedef Node* NodePtr;      /* declares NodePtr to be an alias for
                                       the type Node* */
        NodePtr myBack;             // pointer to the back of the queue
        NodePtr myFront;            // pointer to the front of the queue
        int mySize;                 // current size of the queue

};//--- end of PriorityQueue class

//------ Prototype of output operator
template <typename ElementType>
ostream& operator<<(ostream&out, const PriorityQueue<ElementType>& q) {
    q.display(out);
    return out;
}

#endif