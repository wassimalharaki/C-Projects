#include "DoublyCircularList.h"
#include <iomanip>

using std::setw;
using std::left;
using std::cin;
using std::cout;

void displayOptions();

int main()
{
    DCList myTestList;
    int choice;
    int position;
    int counter;
    ElementType element;


    cout << "\nWelcome to Doubly-Circular Linked List Test program\n"
         << "An Empty DCList of integers has been created for you.\n";
    displayOptions();
    cin >> choice;


    while (choice != 11)
    {
        switch (choice)
        {
            case 1:
                cout << "\nEnter the element to insert:\n";
                cin >> element;
                myTestList.insertAtBeginning(element);
                cout << "\nElement was inserted successfully in the "
                     << "beginning of the list\n";
                cout << myTestList;
                break;

            case 2:
                cout << "\nEnter the element to insert:\n";
                cin >> element;
                myTestList.insertAtEnd(element);
                cout << "\nElement was inserted successfully at the "
                     << "end of the list\n";
                cout << myTestList;
                break;

            case 3:
                cout << "\nEnter the position of the list you would "
                     << "like to insert an element at "
                     << "(any value >= 1): ";
                cin >> position;
                cout << "\nEnter the element to insert:\n";
                cin >> element;
                if (myTestList.insertAtPosition(element, position - 1))
                {
                    cout << "\nElement was inserted successfully at "
                         << "position " << position << "\n";
                    cout << myTestList;
                }
                break;

            case 4:
                cout << "\nEnter the position of the element to "
                     << "delete (any value >= 1): ";
                cin >> position;
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                if (myTestList.deleteAtPosition(position - 1))
                {
                    cout << "\nElement was deleted successfully at "
                         << "position " << position << "\n";
                    cout << myTestList;
                }
                break;

            case 5:
                cout << "\nEnter the element following the one you "
                     << "want to delete:\n";
                cin >> element;
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                if (myTestList.deleteBeforeAnElement(element))
                {
                    cout << "\nElement before " << element
                         << " was deleted successfully\n";
                    cout << myTestList;
                }
                break;

            case 6:
                cout << "\nEnter the element you want to find:\n";
                cin >> element;
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                if (myTestList.search(element))
                    cout << "\nElement was found in the list\n\n";
                else
                    cout << "\nElement was NOT found in the list\n\n";
                break;

            case 7:
                cout << "\nEnter the element you want to delete:\n";
                cin >> element;
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                counter = myTestList.findAndDelete(element);
                if (counter != 0)
                {
                    cout << "\nAll occurrences (" << counter
                         << ") of " << element
                         << " were deleted successfully\n";
                    cout << myTestList;
                }
                else
                    cout << "\nElement was NOT found in the list\n\n";
                break;

            case 8:
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                if (myTestList.removeFirst())
                {
                    cout << "\nFirst element was deleted " 
                         << "successfully\n";
                    cout << myTestList;
                }
                break;

            case 9:
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                if (myTestList.removeLast())
                {
                    cout << "\nLast element was deleted "
                         << "successfully\n";
                    cout << myTestList;
                }
                break;

            case 10:
                if (myTestList.isEmpty())
                {
                    cerr << "\nList is empty\n\n";
                    break;
                }
                cout << "\n" << myTestList.deleteDuplicates()
                     << " duplicate elements were deleted from "
                     << "the list\n";
                cout << myTestList;
                break;

            case 11:
                break;

            default:
                cout << "\nInvalid option\n\n";
        }

        displayOptions();
        cin >> choice;
    }

    cout << "\nThank you for using the program.\n\n";
    return 0;
}

void displayOptions()
{
    cout << left << "Please choose one of the following options:\n\n"
         << setw(6) << "1-"  << "Insert at beginning\n"
         << setw(6) << "2-"  << "Insert at end\n"
         << setw(6) << "3-"  << "Insert at position\n"
         << setw(6) << "4-"  << "Delete at position\n"
         << setw(6) << "5-"  << "Delete before an element\n"
         << setw(6) << "6-"  << "Search element\n"
         << setw(6) << "7-"  << "Find and delete\n"
         << setw(6) << "8-"  << "Remove first element\n"
         << setw(6) << "9-"  << "Remove last element\n"
         << setw(6) << "10-" << "Delete duplicated elements\n"
         << setw(6) << "11-" << "Exit\n\n";
}