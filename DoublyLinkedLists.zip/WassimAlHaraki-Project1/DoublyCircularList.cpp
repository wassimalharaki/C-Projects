/**
 * @file DoublyCircularList.cpp
 * 
 * @author Wassim Al Haraki
 */

/*-- DoublyCircularList.cpp -------------------------------------------------
   This file implements DCList member functions.
-------------------------------------------------------------------------*/

#include "DoublyCircularList.h"

//--- Definition of class constructor
DCList::DCList()
{
    mySize = 0;
    myFirst = NULL;
}

//--- Definition of copy constructor
DCList::DCList(const DCList& orig)
{
    mySize = 0;
    myFirst = NULL;

    // if orig is empty return
    if (orig.isEmpty())
        return;
    
    NodePtr current = orig.myFirst;
    
    // insert all data from orig into this list
    for (; mySize < orig.mySize; current = current->successor)
        insertAtEnd(current->data);
}

//--- Definition of assignment operator
const DCList& DCList::operator=(const DCList& right)
{
    // in case of self assignment, return this list
    if (this == &right)
        return *this;
    // else
    this->~DCList();

    mySize = 0;
    myFirst = NULL;

    // if right is empty, return
    if (right.isEmpty())
        return *this;
    
    NodePtr current = right.myFirst;

    // insert all data from right into this list
    for (; mySize < right.mySize; current = current->successor)
        insertAtEnd(current->data);

    return *this;
}

//--- Definition of destructor
DCList::~DCList()
{
    if (isEmpty())
        return;

    // current points to myFirst
    NodePtr current = myFirst;

    // toDelete points to the same node
    NodePtr toDelete = current;

    // current moves, toDelete is deleted
    // then toDelete follows current until all
    // nodes are deleted
    for (int i = 0; i < mySize; i++)
    {
        current = current->successor;
        delete toDelete;
        toDelete = current;
    }
}

//--- Definition of isEmpty()
bool DCList::isEmpty() const
{
    return mySize == 0;
}

//--- Definition of searchNode()
DCList::NodePtr DCList::searchNode(const ElementType& data) const
{
    if (isEmpty())
        return NULL;
    
    // current starts at the last node so that
    // the first time current points to the next node
    // it will be pointing to the first node
    NodePtr current = myFirst->predecessor;

    // iterate over the all the nodes
    // if a node with data equal to the data
    // given is found, return a pointer to it
    for (int i = 0; i < mySize; i++)
    {
        current = current->successor;
        if (current->data == data)
            return current;
    }
    // if not found, return NULL
    return NULL;
}

//--- Definition of traverseNodes()
DCList::NodePtr DCList::traverseNodes(int position) const
{
    if (isEmpty() || position < 0 || position > mySize)
        return NULL;

    NodePtr pred = myFirst->predecessor;

    // if position is in the lower half of the list
    // move forwards to it (using ->successor)
    if (position <= (mySize - 1)/2)
    {
        
        // move forward until the
        // predecessor node is reached
        for (int i = 0; i < position; i++)
            pred = pred->successor;
    }
    // else if the position is in the upper half of the list
    // move backwards to it (using ->predecessor)
    else
    {

        // move backwards until the
        // predecessor node is reached
        for (int i = 0; i < mySize - position; i++)
            pred = pred->predecessor;
    }

    // return a pointer to the predecessor node
    return pred;
}

//--- Definition of search()
bool DCList::search(const ElementType& data) const
{
    if (isEmpty())
        exit(1);
    
    if(searchNode(data) == NULL)
        return false;

    return true;
}

//--- Definition of insertAtPosition()
bool DCList::insertAtPosition(const ElementType& data, int position)
{
    if (position < 0 || position > mySize)
    {
        cerr << "\nInvalid position\n\n";
        return false;
    }

    // toInsert is a pointer that points to a new node
    // to be inserted in the list
    NodePtr toInsert = new DoublyNode(data);

    // if list is empty
    // (insertion at position 0 of an empty list)
    // myFirst points to the new node
    // new node points to itself as its
    // predecessor and successor
    if (isEmpty())
    {
        myFirst = toInsert;
        toInsert->predecessor = toInsert;
        toInsert->successor = toInsert;
        mySize++;
        return true;
    }
    // if list is not empty

    // pred points to the predecessor of
    // the node to be inserted at
    // no need to check if pred is NULL
    // since conditions are checked before
    // sending position to traverseNodes()
    NodePtr pred = traverseNodes(position);
    NodePtr succ = pred->successor;
    
    // if position is 0,
    // the new node becomes the first node
    if (position == 0)
        myFirst = toInsert;

    // the new node points to pred and succ
    // as its predecessor and successor nodes
    toInsert->predecessor = pred;
    toInsert->successor = succ;

    // predecessor and successor nodes
    // point to the new node appropriately
    pred->successor = toInsert;
    succ->predecessor = toInsert;
    mySize++;
    return true;
}

//--- Definition of insertAtEnd()
bool DCList::insertAtEnd(const ElementType& data)
{
    // mySize is the end of the list
    return insertAtPosition(data, mySize);
}

//--- Definition of insertAtBeginning()
bool DCList::insertAtBeginning(const ElementType& data)
{
    // 0 is the beginning of the list
    return insertAtPosition(data, 0);
}

//--- Definition of deleteANode()
bool DCList::deleteANode(NodePtr toDelete)
{
    if (isEmpty() || toDelete == NULL)
        return false;

    NodePtr pred = toDelete->predecessor;
    NodePtr succ = toDelete->successor;

    // if first element is to be deleted
    if (toDelete == myFirst)
        myFirst = succ;

    // pred and succ point to each other
    // and toDelete is deleted
    pred->successor = succ;
    succ->predecessor = pred;
    delete toDelete;
    mySize--;
    return true;
}

//--- Definition of deleteAtPosition()
bool DCList::deleteAtPosition(int position)
{
    if (isEmpty())
        exit(1);

    if (position < 0 || position >= mySize)
    {
        cerr << "\nInvalid position\n\n";
        return false;
    }

    // if there is only one element in the list
    // (deletion of the only element in a list)
    // myFirst gets deleted and points to null
    if (mySize == 1)
    {
        delete myFirst;
        myFirst = NULL;
        mySize--;
        return true;
    }

    // pred points to the predecessor of
    // the node to be deleted
    NodePtr pred = traverseNodes(position);

    return deleteANode(pred->successor);
}

//--- Definition of deleteAValue()
bool DCList::deleteAValue(const ElementType& data)
{
    if (isEmpty())
        exit(1);

    // if the only element is to be deleted
    if (mySize == 1 && myFirst->data == data)
    {
        delete myFirst;
        myFirst = NULL;
        mySize--;
        return true;
    }

    NodePtr toDelete = searchNode(data);
    
    // if element was not found
    if (toDelete == NULL)
    {
        cerr << "\nElement was NOT found in the list\n\n";
        return false;
    }
    // else delete the element

    return deleteANode(toDelete);
}

//--- Definition of deleteBeforeAnElement()
bool DCList::deleteBeforeAnElement(const ElementType& data)
{
    if (isEmpty())
        exit(1);

    // if there is only one element in the list,
    // and it has the same data, the element
    // before it is itself, delete the element
    if (mySize == 1 && myFirst->data == data)
    {
        delete myFirst;
        myFirst = NULL;
        mySize--;
        return true;
    }

    NodePtr succ = searchNode(data);

    // if element was not found
    if (succ == NULL)
    {
        cerr << "\nElement was NOT found in the list\n\n";
        return false;
    }
    // else delete the previous element

    return deleteANode(succ->predecessor);
}

//--- Definition of findAndDelete()
int DCList::findAndDelete(const ElementType& data)
{
    if(isEmpty())
        exit(1);

    int count = 0;
    NodePtr current = myFirst;

    // iterate over the list, if data is found
    // in any element, delete it
    for (int i = 0; i < mySize; i++)
        if (current->data == data)
        {

            // save the node succeeding toCompare
            // node because toCompare->successor
            // cannot be used to move to the next
            // node if toCompare were deleted
            NodePtr succ = current->successor;
            deleteANode(current);
            count++;

            // decrement i since an element was
            // deleted
            i--;
            current = succ;
        }
        else
            current = current->successor;

    // ******** ANOTHER METHOD ********
    // This is another method for deleting duplicates.
    // The difference between both methods is that
    // the previous one deletes the node using a pointer
    // to it, while this one deletes the node using its
    // position, which is less efficient since deleting
    // at a position means that the function has to find
    // the node first, then delete it, this part is skipped
    // in the previous method since it deletes it directly.
    // This method uses a previously created function
    // (deleteAtPosition()) which is what is required
    // in the project, while the previous one doesn't
    // (deleteANode() is function I created).

    /**
     * for (int i = 0; i < mySize; i++)
     *     if (current->data == data)
     *     {
     *         current = current->successor;
     *         deleteAtPosition(i--);
     *         count++;
     *     }
     *     else
     *         current = current->successor;
     */

    // ******** ANOTHER METHOD ********
    // This is another method for deleting duplicates.
    // This method is highly inefficient.

    /**
     * for (; searchNode(data) != NULL; count++)
     *     deleteAValue(data);
     */

    return count;
}

//--- Definition of removeFirst()
ElementType DCList::removeFirst()
{
    if (isEmpty())
        exit(1);

    // save data of the element
    ElementType data = myFirst->data;
    deleteANode(myFirst);

    // return data after deletion
    return data;
}

//--- Definition of removeLast()
ElementType DCList::removeLast()
{   
    if (isEmpty())
        exit(1);

    // save data of the element
    ElementType data = myFirst->predecessor->data;
    deleteANode(myFirst->predecessor);

    // return data after deletion
    return data;
}

//--- Definition of deleteDuplicates()
int DCList::deleteDuplicates()
{
    if (isEmpty())
        exit(1);

    int count = 0;
    NodePtr current = myFirst;

    // comparison starts from the node after
    // current
    NodePtr toCompare = current->successor;

    // iterate over the list, after each
    // iteration, compare the current node
    // with all the nodes succeeding it in
    // the list, if they hold the same data
    // delete the duplicate node, else
    // keep comparing until the list ends,
    // then move to another node to compare
    for (int i = 0; i < mySize; i++)
    {

        // compare the current node with all the
        // nodes succeeding it until end of list
        // if they hold the same data, delete
        // the duplicate node, else keep comparing
        for (int j = i + 1; j < mySize; j++)
            if (current->data == toCompare->data)
            {

                // save the node succeeding toCompare
                // node because toCompare->successor
                // cannot be used to move to the next
                // node if toCompare were deleted
                NodePtr succ = toCompare->successor;
                deleteANode(toCompare);
                count++;

                // decrement j since an element was
                // deleted
                j--;
                toCompare = succ;
            }
            else
                toCompare = toCompare->successor;

        // after duplicates of the current node are
        // deleted, move to the next current node
        current = current->successor;
        toCompare = current->successor;
    }


    // ******** ANOTHER METHOD ********
    // This is another method for deleting duplicates.
    // The difference between both methods is that
    // the previous one deletes the node using a pointer
    // to it, while this one deletes the node using its
    // position, which is less efficient since deleting
    // at a position means that the function has to find
    // the node first, then delete it, this part is skipped
    // in the previous method since it deletes it directly.
    // This method uses a previously created function
    // (deleteAtPosition()) which is what is required
    // in the project, while the previous one doesn't
    // (deleteANode() is function I created).
    //
    // The previous method can get up to 5 times faster
    // than this method based on the size of the list,
    // number of duplicates in the list, and their 
    // position.
    //
    // (tests were made using chrono library to time
    // each method in different scenarios; when list
    // contains 500 elements that are the same, 500
    // alternating elements (between 0 and 9), and more)

    /**
     * for (int i = 0; i < mySize; i++)
     * {
     *     for (int j = i + 1; j < mySize; j++)
     *         if (current->data == toCompare->data)
     *         {
     *             toCompare = toCompare->successor;
     *             deleteAtPosition(j--);
     *             count++;
     *         }
     *         else
     *             toCompare = toCompare->successor;
     * 
     *     current = current->successor;
     *     toCompare = current->successor;
     * }
     */

    // ******** ANOTHER METHOD ********
    // This is another method for deleting duplicates.
    // This method is highly inefficient.

    /**
     * for (int i = 0; i < mySize; i++)
     * {
     *     const ElementType data = current->data;
     *     count += findAndDelete(data) - 1;
     *     insertAtPosition(data, i);
     *     current = searchNode(data)->successor;
     * }
     */

    return count;
}

//--- Definition of display()
ostream& DCList::display(ostream& out) const
{
    if (isEmpty())
    {
        cerr << "\nList is empty\n\n";
        return out;
    }

    out << "\nList elements: " << myFirst->data;
    NodePtr current = myFirst;
    for (int i = 1; i < mySize; i++)
    {
        current = current->successor;
        out << ", " << current->data;
    }
    out << "\n\n";
    return out;
}

//--- Definition of output operator
ostream& operator<<(ostream& out, const DCList& list)
{
    list.display(out);
    return out;
}