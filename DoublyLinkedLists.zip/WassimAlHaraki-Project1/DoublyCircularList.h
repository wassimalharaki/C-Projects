/**
 * @file DoublyCircularList.h
 * 
 * @author Wassim Al Haraki
 */

/*-- DoublyCircularList.h ----------------------------------------------------
    This header file defines the data type DCList for processing lists.
    Basic operations are:
        Constructor
        Copy constructor
        =:                      Assignment operator
        Destructor
        isEmpty:                Check if list is empty
        search:                 Search for an element
        searchNode:             Search for node of an element
        traverseNodes:          Search for node before a position
        insertAtPosition:       Insert an element
        insertAtEnd:            Insert an element at the end
        insertAtBeginning:      Insert an element at the beginning
        deleteAtPosition:       Remove an element at a position
        deleteANode:            Remove a node
        deleteAValue:           Remove an element
        deleteBeforeAnElement:  Remove the element before the current
        findAndDelete:          Remove all occurrences of an element
        removeFirst:            Remove and return first element
        removeLast:             Remove and return last element
        deleteDuplicates:       Remove duplicates of an element
        display:                Output the list
        <<:                     Output operator

    Class Invariant:
        1. mySize >= 0
        2. List size is not limited
 -------------------------------------------------------------------------*/
#ifndef DOUBLYCIRCULARLIST
#define DOUBLYCIRCULARLIST

#include <iostream>

using std::ostream;
using std::cerr;

typedef int ElementType;    /* declares ElementType to be an alias
                               for the type int */

class DCList
{
    public:
    /******** Functions Members ********/
        /***** Class constructor *****/
        DCList();
        /*----------------------------------------------------------------------
            Constructs a DCList object.

            Precondition:  None
            Postcondition: An empty DCList object is constructed;
                myFirst = NULL and mySize = 0.
        -----------------------------------------------------------------------*/
        
        /***** Copy constructor *****/
        DCList(const DCList& orig);
        /*----------------------------------------------------------------------
            Constructs a copy of a DCList object.

            Precondition:  A copy of orig is needed; orig is a const
                reference parameter. 
            Postcondition: A copy of orig has been constructed.
        -----------------------------------------------------------------------*/

        //------ Prototype of assignment operator
        const DCList& operator=(const DCList& orig);
        /*----------------------------------------------------------------------
            Assigns a copy of a DCList object to the current object.

            Precondition:  None
            Postcondition: A copy of orig has been assigned to this
                object. A const reference to this list is returned.
        -----------------------------------------------------------------------*/
        
        /***** Class destructor *****/
        ~DCList();
        /*----------------------------------------------------------------------
            Destroys a DCList object.

            Precondition:  The life of a DCList object is over.
            Postcondition: The memory dynamically for the DoublyNode
                objects in the list has been returned to the heap.
        -----------------------------------------------------------------------*/
        
        /***** empty operation *****/
        bool isEmpty() const;
        /*----------------------------------------------------------------------
            Checks if the list is empty.

            Precondition:  None
            Postcondition: true is returned if the list is empty, false if not.
        -----------------------------------------------------------------------*/
        
        /***** search for element *****/
        bool search(const ElementType& data) const;
        /*----------------------------------------------------------------------
            Checks if an element exists in the list.

            Precondition:  data is a nonnull variable of type ElementType and
                list is not empty.
            Postcondition: true is returned if element is found, false if not
                (provided list is not empty).
        -----------------------------------------------------------------------*/

        /***** insert at index *****/
        bool insertAtPosition(const ElementType& data, int position);
        /*----------------------------------------------------------------------
            Inserts an element into the list at a given position.

            Precondition:  data is a nonnull variable of type ElementType.
            Postcondition: element has been inserted into the list at the index
                determined by position (provided position is a valid index).
        -----------------------------------------------------------------------*/
        
        /***** insert at end *****/
        bool insertAtEnd(const ElementType& data);
        /*----------------------------------------------------------------------
            Inserts an element into the end of the list.

            Precondition:  data is a nonnull variable of type ElementType.
            Postcondition: element has been inserted into the end of the list.
        -----------------------------------------------------------------------*/

        /***** insert at beginning *****/
        bool insertAtBeginning(const ElementType& data);
        /*----------------------------------------------------------------------
            Inserts an element into the beginning of the list.

            Precondition:  data is a nonnull variable of type ElementType.
            Postcondition: element has been inserted into the beginning of the
                list.
        -----------------------------------------------------------------------*/

        /***** delete at position *****/
        bool deleteAtPosition(int position);
        /*----------------------------------------------------------------------
            Removes an element from the list at a given index.

            Precondition:  list is not empty.
            Postcondition: element at the index determined by position has been
                removed (provided list is not empty and position is a valid
                index).
        ----------------------------------------------------------------------*/

        /***** delete before an element *****/
        bool deleteBeforeAnElement(const ElementType& data);
        /*----------------------------------------------------------------------
            Removes the element preceding the first element with a given value
            from the list.

            Precondition:  data is a nonnull variable of type ElementType and
                list is not empty.
            Postcondition: element preceding the first element with a given
                value has been removed (provided list is not empty and first
                element was found).
        ----------------------------------------------------------------------*/
        
        /***** find and delete *****/
        int findAndDelete(const ElementType& data);
        /*----------------------------------------------------------------------
            Removes all occurrences of an element in the list.

            Precondition:  data is a nonnull variable of type ElementType and
                list is not empty.
            Postcondition: all occurences of an element have been removed
                (provided list is not empty).
        ----------------------------------------------------------------------*/

        /***** remove first element ******/
        ElementType removeFirst();
        /*----------------------------------------------------------------------
            Removes the first element in the list.

            Precondition:  list is not empty.
            Postcondition: first element has been removed (provided list is
                not empty).
        ----------------------------------------------------------------------*/
        
        /***** remove last element *****/
        ElementType removeLast();
        /*----------------------------------------------------------------------
            Removes the last element in the list.

            Precondition:  list is not empty.
            Postcondition: last element has been removed (provided list is
                not empty).
        ----------------------------------------------------------------------*/
        
        /***** delete duplicates *****/
        int deleteDuplicates();
        /*----------------------------------------------------------------------
            Removes duplicates of an element in the list.

            Precondition:  data is a nonnull variable of type ElementType and 
                list is not empty.
            Postcondition: all duplicates of an element have been removed
                (provided list is not empty).
        ----------------------------------------------------------------------*/

        /***** output *****/
        ostream& display(ostream& out) const;
        /*----------------------------------------------------------------------
            Displays a list.

            Precondition:  The ostream out is open. 
            Postcondition: The list represented by this DCList object has
                been inserted into out. 
        -----------------------------------------------------------------------*/

    private:
    /******** Data Members ********/
        /**
         * A DoublyNode holds data and points to the preceding and succeeding
         * DoublyNode.
         * 
         * All DoublyNodes initially hold what is passed to it as data,
         * and NULL as the pointers pointing to the preceding and succeeding
         * DoublyNodes.
         * 
         * User is free to change data or pointers after initialization.
         */
        class DoublyNode
        {
            public:
            /******** Data Members ********/
                ElementType data;           // data of DoublyNode
                DoublyNode* predecessor;    /* pointer to the preceding
                                               DoublyNode */
                DoublyNode* successor;      /* pointer to the succeeding
                                               DoublyNode */
            
            /******** Functions Members ********/
                /***** Class constructor *****/
                DoublyNode(const ElementType& n)
                {
                    data = n;
                    predecessor = NULL;
                    successor = NULL;
                }
                /*----------------------------------------------------------------------
                    Constructs a DoublyNode object

                    Precondition:  n is a nonnull variable of type ElementType.
                    Postcondition: A DoublyNode is constructed; data = n;
                        predecessor and successor = NULL;
                ----------------------------------------------------------------------*/
        };//--- end of DoublyNode class

        typedef DoublyNode* NodePtr;    /* declares NodePtr to be an alias for
                                           the type DoublyNode* */
        int mySize;                     // current size of DCList
        NodePtr myFirst;                // pointer to the first element in DCList

        /***** search for node *****/
        NodePtr searchNode(const ElementType& data) const;
        /*----------------------------------------------------------------------
            Searches for an element in the list and returns a pointer to it.

            Precondition:  data is a nonnull variable of type ElementType.
            Postcondition: a pointer to the element is returned if the element
                is found, NULL if not or if list is empty.
        -----------------------------------------------------------------------*/

        /***** traverse the nodes *****/
        NodePtr traverseNodes(int position) const;
        /*----------------------------------------------------------------------
            Traverses to the DoublyNode preceding the DoublyNode at the index
            determined by position and returns a pointer to it.

            Precondition:  None
            Postcondition: a pointer to the preceding the DoublyNode at the
                index determined by position is returned (provided list is
                not empty and position is a valid index).
        -----------------------------------------------------------------------*/
                
        /***** delete a node *****/
        bool deleteANode(NodePtr toDelete);
        /*----------------------------------------------------------------------
            Removes a node from the list.

            Precondition:  None
            Postcondition: node pointed at by toDelete has been removed
                (given that toDelete is not NULL, list is not empty, and
                toDelete belongs to this list).
        ----------------------------------------------------------------------*/
        
        /***** delete an element *****/
        bool deleteAValue(const ElementType& data);
        /*----------------------------------------------------------------------
            Removes the first element with a given value from the list.

            Precondition:  data is a nonnull variable of type ElementType and
                list is not empty.
            Postcondition: first element with a given value has been removed
                (provided list is not empty).
        ----------------------------------------------------------------------*/
}; //--- end of DCList class

//------ Prototype of output operator
ostream& operator<<(ostream& out, const DCList& list);

#endif