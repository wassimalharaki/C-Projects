#include <iostream>

using namespace std;

int main() {
    int n;
    cin >> n;
    int** sols = new int*[n];
    for (int i = 0; i < n; i++)
        sols[i] = new int[3];

    for (int i = 0; i < n; i++)
        for (int j = 0; j < 3; j++)
            cin >> sols[i][j];

    int counter = 0;
    for (int i = 0; i < n; i++) {
        int questCounter = 0;
        for (int j = 0; j < 3; j++)
            if (sols[i][j] == 1)
                questCounter++;
        if (questCounter >= 2)
            counter++;
    }
    cout << counter;
    
    return 0;
}