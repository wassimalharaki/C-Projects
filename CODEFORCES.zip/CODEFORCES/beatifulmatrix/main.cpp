#include <iostream>

using namespace std;

int main() {
    int matrix[5][5];
    int rowOf1;
    int colOf1;
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++) {
            cin >> matrix[i][j];
            if (matrix[i][j] == 1) {
                rowOf1 = i;
                colOf1 = j;
            }
        }
    
    cout << abs(2-rowOf1) + abs(2-colOf1);


    return 0;
}