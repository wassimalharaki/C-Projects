#include <iostream>
#include <string.h>

using namespace std;

int main() {
    int num, x = 0;
    cin >> num;
    string op;

    for (int i = 0; i < num; i++) {
        cin >> op;
        if (op.find("++") != string::npos)
            x++;
        else
            x--;
    }

    cout << x;
    
    return 0;
}