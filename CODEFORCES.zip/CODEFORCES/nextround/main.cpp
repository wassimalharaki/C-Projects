#include <iostream>

using namespace std;

int main() {
    int n, k;
    cin >> n >> k;

    int grades[n];

    for (int i = 0; i < n; i++)
        cin >> grades[i];

    int counter = 0;
    for (int i = 0; i < n; i++)
        if (grades[i] >= grades[k-1] && grades[i] > 0)
            counter++;

    cout << counter;

    return 0;
}