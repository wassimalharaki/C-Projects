#include <iostream>
#include <string.h>
using namespace std;

int main() {
    char* exp;
    cin >> exp;
    char* corrExp = new char[strlen(exp)];
    int j = 0;
    for (int i = 0; i < strlen(exp); i++)
        if (exp[i] == '1') {
            corrExp[j++] = '1';
            corrExp[j++] = '+';
        }
    
    for (int i = 0; i < strlen(exp); i++)
        if (exp[i] == '2') {
            corrExp[j++] = '2';
            corrExp[j++] = '+';
        }
    
    for (int i = 0; i < strlen(exp); i++)
        if (exp[i] == '2') {
            corrExp[j++] = '3';
            corrExp[j++] = '+';
        }

    cout << corrExp;

    return 0;
}